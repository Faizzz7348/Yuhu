import MachineSelector from '../MachineSelector';

export default function MachineSelectorExample() {
  return (
    <div className="p-4">
      <MachineSelector currentMachineId="M0001" />
    </div>
  );
}
