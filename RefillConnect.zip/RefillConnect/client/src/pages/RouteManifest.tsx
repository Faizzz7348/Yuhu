import { useState, useEffect } from "react";
import { useParams } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Truck, MapPin, Package, CheckCircle2, AlertCircle, ChevronRight, Calendar, Clock, Gauge, Save } from "lucide-react";
import RefillDialog from "@/components/RefillDialog";
import type { Machine, Product } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useData } from "@/contexts/DataContext";

const mockProducts: Record<string, Product[]> = {
  "M0001": [
    { id: "1", machineId: "M0001", name: "Chicken Slice X", currentStock: 5, capacity: 6 },
    { id: "2", machineId: "M0001", name: "Mayo Sandwich", currentStock: 3, capacity: 6 },
    { id: "3", machineId: "M0001", name: "Double Chicken Slice", currentStock: 2, capacity: 6 },
    { id: "4", machineId: "M0001", name: "Chicken Floss Sandwich", currentStock: 2, capacity: 6 },
    { id: "5", machineId: "M0001", name: "Sardines Sandwich", currentStock: 4, capacity: 6 },
    { id: "6", machineId: "M0001", name: "Kani Mayo", currentStock: 5, capacity: 6 },
    { id: "7", machineId: "M0001", name: "Classic Tuna Sandwich", currentStock: 3, capacity: 6 },
    { id: "8", machineId: "M0001", name: "Spicy Tuna Sandwich", currentStock: 5, capacity: 6 },
    { id: "9", machineId: "M0001", name: "Big Bite", currentStock: 3, capacity: 6 },
    { id: "10", machineId: "M0001", name: "Double Egg Mayo", currentStock: 4, capacity: 6 },
  ],
  // Similar products for other machines
};

export default function RouteManifest() {
  const { id } = useParams();
  const routeId = id || "ROUTE-001";
  const { routes, machines: allMachines, addRefillHistory } = useData();
  const route = routes.find((r) => r.id === routeId);
  const machines = allMachines.filter((m) => m.routeId === routeId);
  
  const [driverName, setDriverName] = useState("");
  const [assistanceName, setAssistanceName] = useState("");
  const [backupName, setBackupName] = useState("");
  const [lorryNumber, setLorryNumber] = useState("");
  const [odometerStart, setOdometerStart] = useState("");
  const [odometerEnd, setOdometerEnd] = useState("");
  const [odometerDialogOpen, setOdometerDialogOpen] = useState(false);
  const [savedOdometer, setSavedOdometer] = useState<{ start: string; end: string } | null>(null);
  const [selectedMachine, setSelectedMachine] = useState<string | null>(null);
  const [completedMachines, setCompletedMachines] = useState<Set<string>>(new Set());
  const [machineProducts, setMachineProducts] = useState<Record<string, Product[]>>({});
  const [currentDateTime, setCurrentDateTime] = useState(new Date());
  const { toast } = useToast();

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleSaveOdometer = () => {
    if (!odometerStart.trim() || !odometerEnd.trim()) {
      toast({
        title: "Error",
        description: "Please enter both start and end odometer readings",
        variant: "destructive",
      });
      return;
    }

    const start = parseFloat(odometerStart);
    const end = parseFloat(odometerEnd);

    if (isNaN(start) || isNaN(end)) {
      toast({
        title: "Error",
        description: "Please enter valid numbers",
        variant: "destructive",
      });
      return;
    }

    if (end < start) {
      toast({
        title: "Error",
        description: "End odometer reading must be greater than start reading",
        variant: "destructive",
      });
      return;
    }

    setSavedOdometer({ start: odometerStart, end: odometerEnd });
    setOdometerDialogOpen(false);
    toast({
      title: "Odometer Saved",
      description: `Distance: ${(end - start).toFixed(1)} km`,
    });

    console.log("Odometer readings saved:", {
      start: odometerStart,
      end: odometerEnd,
      distance: end - start,
      timestamp: new Date().toISOString(),
    });
  };

  const handleStartRefill = (machineId: string) => {
    if (!driverName.trim()) {
      toast({
        title: "Driver Name Required",
        description: "Please enter driver name first",
        variant: "destructive",
      });
      return;
    }

    // Initialize products for machine if not already loaded
    if (!machineProducts[machineId]) {
      setMachineProducts(prev => ({
        ...prev,
        [machineId]: mockProducts["M0001"].map(p => ({ ...p, machineId }))
      }));
    }

    setSelectedMachine(machineId);
  };

  const handleRefill = (
    updates: Record<string, number>, 
    deliveryDetails: { name: string; assistance: string; backup: string; lorry: string; notes: string },
    quantities: Record<string, { in: number; overflow: number; out: number }>
  ) => {
    if (!selectedMachine) return;

    const currentDateTime = new Date();
    const currentProducts = machineProducts[selectedMachine] || [];
    
    // Build product updates for history using actual quantities
    const productUpdates = currentProducts.map(product => {
      const netChange = updates[product.id] || 0;
      const newStock = Math.min(product.currentStock + netChange, product.capacity);
      const productQuantities = quantities[product.id] || { in: 0, overflow: 0, out: 0 };
      
      return {
        productName: product.name,
        in: productQuantities.in,
        overflow: productQuantities.overflow,
        out: productQuantities.out,
        previousStock: product.currentStock,
        newStock: newStock,
      };
    });

    // Add to refill history
    addRefillHistory({
      id: `REFILL-${Date.now()}`,
      machineId: selectedMachine,
      date: currentDateTime.toISOString(),
      driverName: deliveryDetails.name,
      assistanceName: deliveryDetails.assistance,
      backupName: deliveryDetails.backup,
      lorryNumber: deliveryDetails.lorry,
      notes: deliveryDetails.notes,
      productUpdates,
    });
    
    setMachineProducts(prev => ({
      ...prev,
      [selectedMachine]: prev[selectedMachine]?.map(product => ({
        ...product,
        currentStock: Math.min(
          product.currentStock + (updates[product.id] || 0),
          product.capacity
        ),
      })) || []
    }));

    setCompletedMachines(prev => new Set(prev).add(selectedMachine));

    toast({
      title: "Machine Refilled",
      description: `${selectedMachine} completed by ${deliveryDetails.name}`,
    });

    console.log("Refill completed:", {
      machineId: selectedMachine,
      updates,
      driver: deliveryDetails.name,
      assistance: deliveryDetails.assistance,
      backup: deliveryDetails.backup,
      lorry: deliveryDetails.lorry,
      notes: deliveryDetails.notes,
      dateTime: currentDateTime.toISOString(),
    });

    setSelectedMachine(null);
  };

  const getFrequencyBadge = (machineId: string) => {
    const machine = machines.find(m => m.id === machineId);
    if (!machine) return null;

    const frequencyColors = {
      "Daily": "bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20",
      "Weekday": "bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20",
      "Alt 1": "bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20",
      "Alt 2": "bg-orange-500/10 text-orange-600 dark:text-orange-400 border-orange-500/20",
    };

    return (
      <Badge 
        className={`${frequencyColors[machine.frequency]} text-xs`}
        data-testid={`badge-frequency-${machineId}`}
      >
        {machine.frequency}
      </Badge>
    );
  };

  const progressCount = completedMachines.size;
  const totalMachines = machines.length;

  if (!route) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Route not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* Route Header */}
        <Card className="glass-card">
          <CardHeader>
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-2 flex-1">
                <CardTitle className="text-lg font-bold">{route.name}</CardTitle>
                <p className="text-xs text-muted-foreground">{route.description}</p>
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    <span>{currentDateTime.toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{currentDateTime.toLocaleTimeString()}</span>
                  </div>
                </div>
              </div>
              <Badge className="text-sm px-3 py-0.5" data-testid="badge-progress">
                {progressCount} / {totalMachines}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="driver-name" className="text-xs">Driver Name *</Label>
                <Input
                  id="driver-name"
                  placeholder="Enter driver name"
                  value={driverName}
                  onChange={(e) => setDriverName(e.target.value)}
                  data-testid="input-driver-name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="assistance-name" className="text-xs">Assistance Name</Label>
                <Input
                  id="assistance-name"
                  placeholder="Enter assistance name"
                  value={assistanceName}
                  onChange={(e) => setAssistanceName(e.target.value)}
                  data-testid="input-assistance-name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="backup-name" className="text-xs">Backup Name</Label>
                <Input
                  id="backup-name"
                  placeholder="Enter backup name"
                  value={backupName}
                  onChange={(e) => setBackupName(e.target.value)}
                  data-testid="input-backup-name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lorry-number" className="text-xs">Lorry Number</Label>
                <Input
                  id="lorry-number"
                  placeholder="Enter lorry number"
                  value={lorryNumber}
                  onChange={(e) => setLorryNumber(e.target.value)}
                  data-testid="input-lorry-number"
                />
              </div>
            </div>

            <div className="border-t pt-4">
              <div className="flex items-center gap-2 mb-3">
                <Gauge className="w-4 h-4" />
                <Label className="text-xs font-semibold">Odometer Reading</Label>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="odometer-start" className="text-xs">Start (km)</Label>
                  <Input
                    id="odometer-start"
                    type="number"
                    placeholder="0"
                    value={odometerStart}
                    onChange={(e) => setOdometerStart(e.target.value)}
                    data-testid="input-odometer-start"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="odometer-end" className="text-xs">End (km)</Label>
                  <Input
                    id="odometer-end"
                    type="number"
                    placeholder="0"
                    value={odometerEnd}
                    onChange={(e) => setOdometerEnd(e.target.value)}
                    data-testid="input-odometer-end"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs opacity-0">Action</Label>
                  <Button
                    onClick={() => setOdometerDialogOpen(true)}
                    className="w-full text-xs"
                    size="sm"
                    data-testid="button-save-odometer"
                  >
                    <Save className="w-3 h-3 mr-1" />
                    Save
                  </Button>
                </div>
              </div>
              {savedOdometer && (
                <div className="mt-3 text-xs text-muted-foreground">
                  Distance: {(parseFloat(savedOdometer.end) - parseFloat(savedOdometer.start)).toFixed(1)} km
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Machines List */}
        <div className="space-y-3">
          <h2 className="text-sm font-semibold flex items-center gap-2">
            <Package className="w-4 h-4" />
            Machines to Refill
          </h2>
          
          <div className="space-y-3">
            {machines.map((machine) => (
              <Card
                key={machine.id}
                className={`glass-card transition-all duration-200 ${
                  completedMachines.has(machine.id) ? 'opacity-75' : 'hover:shadow-lg'
                }`}
                data-testid={`card-machine-${machine.id}`}
              >
                <CardContent className="p-3">
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono font-semibold text-sm" data-testid={`text-machine-id-${machine.id}`}>
                          {machine.id}
                        </span>
                        {getFrequencyBadge(machine.id)}
                        {completedMachines.has(machine.id) && (
                          <Badge className="bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20 text-xs">
                            <CheckCircle2 className="w-3 h-3 mr-1" />
                            Done
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <MapPin className="w-3 h-3 shrink-0" />
                        <span className="truncate" data-testid={`text-location-${machine.id}`}>
                          {machine.location}
                        </span>
                      </div>
                    </div>
                    
                    <Button
                      onClick={() => handleStartRefill(machine.id)}
                      disabled={completedMachines.has(machine.id)}
                      data-testid={`button-refill-${machine.id}`}
                      className="shrink-0 text-xs h-8"
                      size="sm"
                    >
                      {completedMachines.has(machine.id) ? (
                        <>
                          <CheckCircle2 className="w-3 h-3 mr-1" />
                          Done
                        </>
                      ) : (
                        <>
                          Refill
                          <ChevronRight className="w-3 h-3 ml-1" />
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {/* Refill Dialog */}
      {selectedMachine && machineProducts[selectedMachine] && (
        <RefillDialog
          open={!!selectedMachine}
          onClose={() => setSelectedMachine(null)}
          machineId={selectedMachine}
          products={machineProducts[selectedMachine]}
          deliveryName={driverName}
          assistanceName={assistanceName}
          backupName={backupName}
          lorryNumber={lorryNumber}
          onRefill={(updates, details, quantities) => handleRefill(updates, details, quantities)}
        />
      )}

      {/* Odometer Confirmation Dialog */}
      <Dialog open={odometerDialogOpen} onOpenChange={setOdometerDialogOpen}>
        <DialogContent className="glass-card" data-testid="dialog-odometer">
          <DialogHeader>
            <DialogTitle className="text-base">Confirm Odometer Reading</DialogTitle>
            <DialogDescription className="text-xs">
              Please verify the odometer readings before saving
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Start</p>
                <p className="font-semibold" data-testid="text-odometer-start-confirm">{odometerStart || "0"} km</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">End</p>
                <p className="font-semibold" data-testid="text-odometer-end-confirm">{odometerEnd || "0"} km</p>
              </div>
            </div>
            <div className="border-t pt-3">
              <p className="text-xs text-muted-foreground mb-1">Total Distance</p>
              <p className="text-lg font-bold" data-testid="text-odometer-distance">
                {odometerStart && odometerEnd 
                  ? (parseFloat(odometerEnd) - parseFloat(odometerStart)).toFixed(1)
                  : "0"} km
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setOdometerDialogOpen(false)}
              className="text-xs"
              data-testid="button-cancel-odometer"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSaveOdometer}
              className="text-xs"
              data-testid="button-confirm-odometer"
            >
              <Save className="w-3 h-3 mr-1" />
              Confirm & Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
